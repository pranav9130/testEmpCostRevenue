//namespace 
let empDesignationProfit = { };

//following lines brief for variables and functions of the namespace 
//empDesignationProfit : 
//{
//   object data; contains the data returned by convertData functions
//   object chartOptions; contains chart options for all the charts
//   number totalRevenue; contains total revenue
//   number totalCost; contains total cost
//   number initialTotalProfit; contains initial Total Profit %
//   number currentTotalProfit; contains updated total profit %
//   DataTable profitMarginOriginalDataTable;
//   DataTable profitMarginCopyDataTable; copy is made in order to draw diff charts, changes are made in copy
//   DataTable revenueCostDataTable;
//   Chart profitMarginChart; will be a diff chart
//   Chart revenueCostChart; will be dual bar chart 
  
//   initCharts() will initialize required data-variables, datatables, charts for first time
//   drawCharts() will draw required charts
//   drawDiffChart() will calculate difference and draw diffchart accordingly
//   initControls() initailizes controls for chart manipulation
//   updateEmployeeCount() updates the employee count and modifies the revenue-cost-profit accordingly
  
//   following are the helper functions 

//   convertData( object receivedData ) used for converting received data into workable desired format 
//   calculateProfit( number revenue, number cost ) function that returns profit percentage for given revenue, cost
//   getProfitChange() will return diffrence between initial and current profit in string format 
//                     and will set the appropriate styles based on change value                    
//   getDesignationIndex( string designation ) will return row index of datatable for given designation                      
// }

google.charts.load( 'current', { packages : ['corechart', 'line' ] } );
$.getJSON('empRevenueCostInfo.json', function(data)  {
  empDesignationProfit.convertData(data);
  empDesignationProfit.data = data;
  console.log(empDesignationProfit.data);
  google.charts.setOnLoadCallback( empDesignationProfit.initCharts );
})


/*----------------------------------------------- Code for fetching data  rendering charts-----------------------*/ 

//calculates profit margin for given revenue cost
empDesignationProfit.calculateProfit = function(revenue, cost) {
  //if loop handles revenue = cost = 0 condition
  //where zero is returned instead of Nan(infinty) also 
  //reduces calculation where revenue = cost  
  if( revenue == cost ) return 0;
  return ((revenue - cost) / revenue) * 100;  
};

empDesignationProfit.convertData = function(data){
  //for each designation
  Object.keys(data).forEach( (designation, index) => {
    //obtained designation data eg : associate data 
    let designationData = data[ designation ];
    
    //for each location [ onsite and offshore ]
    Object.keys(designationData).forEach( ( location, index) => {
      //obtaining the designation location profile for eg associate onsite profile
      let profileData = designationData [ location ];
      //calculating standard revenue and cost
      profileData.averageRevenue = profileData.revenue / profileData.count;
      profileData.averageCost = profileData.cost / profileData.count;  
    })
  })
}

//returns change with sign in string fromat, sets the css class of of current total profit based on change value
empDesignationProfit.getProfitChange = function(){
  
  //to fixed is forcing two digits after decimal point and also returning its string representation
  
  let change = empDesignationProfit.currentTotalProfit - empDesignationProfit.initialTotalProfit;
  let formattedNumber = change.toFixed(2); //gonna hold result to be returned  
  if(change < 0){
    //if change is negative
    $('.profit_stats_container .current_profit').removeClass('positive').addClass('negative');
  }
  else if( change > 0 ) {
    //if change is positive "+" is sign is prefixed
    formattedNumber = "+" + formattedNumber;
    $('.profit_stats_container .current_profit').removeClass('negative').addClass('positive');
  }
  else {
    //change == 0
    $('.profit_stats_container .current_profit').removeClass('positive negative');
  }  
  return formattedNumber;  
}

//helper function which finds datatable row index based on employee designation location
empDesignationProfit.getDesignationIndex = function( designation ) {
  return empDesignationProfit.profitMarginOriginalDataTable.getFilteredRows([ { column : 0, value : designation } ])[0];
};

//helper function that provides 

empDesignationProfit.chartOptions = {
  marginChartOptions : {
    title : "Profit Margin ( % )",
    hAxis : {
      title : 'Designation'
    },
    vAxis : {
      title : 'Margin %'
    },
    diff : {
      oldData : {
        color : '#DDE1E4'
      }, 
      newData : {
        widthFactor : 0.5
      }
    },
    animation : {
      startup : true,
      duration : 1000
    }
  },
   revenueCostChartOptions : {
    chart: {
      title: 'Revenue and Cost'
    },
    hAxis: {
      title: 'Designation'
    },
    vAxis: {
      title: 'Cost/Revenue',
      format: 'currency'
    } 
  }
}

empDesignationProfit.initCharts = function(){
  console.log('hey loaded google charts');
  console.log('gonna draw charts');
  //initializing drawing area for Charts
  empDesignationProfit.profitMarginChart = new google.visualization.ColumnChart( document.getElementById('profit_margin_bar_chart') );
  empDesignationProfit.revenueCostChart = new google.visualization.ColumnChart( document.getElementById('revenue_cost_line_chart') );
  
  //defining variables that will hold total of revenue and cost of all designations
  empDesignationProfit.totalRevenue = 0;
  empDesignationProfit.totalCost = 0;
  
  //initializing data and datatables 
  let revenueCostData = empDesignationProfit.data;  
  let revenueCostDataTable = new google.visualization.DataTable(); //data table for revenue cost column chart
  let originalProfitDataTable = new google.visualization.DataTable(); //original data table that will not be modified for profit chart
  let copyProfitDataTable; //updatable dataTable that will be initialized as originalProfitDataTable copy (profit chart)
  
  //defining clumns of revenue cost data table
  revenueCostDataTable.addColumn('string','Designation');
  revenueCostDataTable.addColumn('number', 'Revenue');
  revenueCostDataTable.addColumn('number', 'Cost');
  
  
  //defining columns of original profit data table
  originalProfitDataTable.addColumn('string', 'Designation');
  originalProfitDataTable.addColumn('number', 'Designation Profit');
  
  //generate data tables from revenuecost data 
  Object.keys(revenueCostData).forEach( function(key, index) {
    //summing total onsite-offshore revenue and cost designation wise
    let designationRevenue = revenueCostData[key].onsite.revenue + revenueCostData[key].offshore.revenue;
    let designationCost = revenueCostData[key].onsite.cost + revenueCostData[key].offshore.cost;
    let profitMargin = empDesignationProfit.calculateProfit(designationRevenue, designationCost);
    //adding row in revenue cost data table
    revenueCostDataTable.addRow( [ key, designationRevenue, designationCost ] )
    //adding row in original profit datatable
    originalProfitDataTable.addRow( [ key, profitMargin ] );
    
    //updating total reveneue and cost
    empDesignationProfit.totalRevenue += designationRevenue;
    empDesignationProfit.totalCost += designationCost;
    
    //inserting counters for designation-locatiion
    $('.inc_dec_counter_container.onsite_container').append( getCounterHTMLTemplate( key, 'onsite' ) );
    $('.inc_dec_counter_container.offshore_container').append( getCounterHTMLTemplate( key, 'offshore' ) );
    
  })
  
  //calculating and intializng initial total average profit and its updateable copy
  empDesignationProfit.initialTotalProfit = empDesignationProfit.calculateProfit( empDesignationProfit.totalRevenue, empDesignationProfit.totalCost);
  empDesignationProfit.currentTotalProfit = empDesignationProfit.initialTotalProfit;
  console.log('totalRevenue : ' + empDesignationProfit.totalRevenue);
  console.log('totalCost : ' + empDesignationProfit.totalCost);
  console.log(empDesignationProfit.initialTotalProfit);
  
  copyProfitDataTable = new google.visualization.DataTable( originalProfitDataTable.toJSON() );//data table going to be update
  
  //these datatables are included in namespace 
  empDesignationProfit.profitMarginOriginalDataTable = originalProfitDataTable;
  empDesignationProfit.profitMarginCopyDataTable = copyProfitDataTable;
  empDesignationProfit.revenueCostDataTable = revenueCostDataTable;
  
  //after datatable initialization charts are going to be drawn
  empDesignationProfit.drawCharts();
  //initialize cintrols for controls for chart manipulation
  empDesignationProfit.initControls();
  
  //note :: following inner function can not be used outside this functions scope
  //note :: while backticks can be used for template generation instead of string concatination, support for backticks is not available in very old browsers
  //inner helper function that renders html templates for counter based on designation and location 
  function getCounterHTMLTemplate( designation, location ){
    let counterTemplate =  "<div class = 'col-12 inc_dec_counter_box'>" +
                              "<span>" + designation + "</span>" +
                              "<div class = 'inc_dec_counter noselect' data-designation = '" + designation + "' data-location = '" + location +  "'></div>" +
                           "</div>";
    return counterTemplate;
  }
}

//function to render both charts 
empDesignationProfit.drawCharts = function(){
  empDesignationProfit.revenueCostChart.draw( empDesignationProfit.revenueCostDataTable, empDesignationProfit.chartOptions.revenueCostChartOptions );
  empDesignationProfit.drawDiffChart();
}

//draws diff chart from orginal and copy tables
empDesignationProfit.drawDiffChart = function(){
  console.log('generating diff chart')
  //getting original and copy data
  let originalData = empDesignationProfit.profitMarginOriginalDataTable;
  let copyData = empDesignationProfit.profitMarginCopyDataTable;
  //computing diff data table
  let diffDataTable = empDesignationProfit.profitMarginChart.computeDiff( originalData, copyData ); 
  empDesignationProfit.profitMarginChart.draw( diffDataTable, empDesignationProfit.chartOptions.marginChartOptions );
}

/*----------------------------------------------- END -------------------------------------------------*/
//execution starts from here 
//requesting data from server and loading appropriate packages 
/*----------------------------------------------- Code for initializing and handling chart controls-----------------------*/

//initalizes counters and their event handlers 
empDesignationProfit.initControls = function(){
  
  //initializng profit stats container 
  $('.profit_stats_container .initial_profit').html( empDesignationProfit.initialTotalProfit.toFixed(2) );
  $('.profit_stats_container .change').html( '00.00' );
  $('.profit_stats_container .current_profit').html( empDesignationProfit.currentTotalProfit.toFixed(2) );
  
  //for each counter container
  $(".inc_dec_counter_container .inc_dec_counter_box").each( function(index, parentElement) {
    //each designation type will have its own copy of these variables !!!!
    
    //from container get the child having counter class
    let counterElement = $(parentElement).children('.inc_dec_counter')[0];
    //variable to hold symbol elements and  value element in later part of code
    let valueElement, addSymbolElement, substractSymbolElement;
    //gonna record the variation in count
//     let countVariation = 0;
    
    //obtain info 
    let designation = $(counterElement).attr('data-designation');
    let location = $(counterElement).attr('data-location');
    let employeeCount = empDesignationProfit.data[ designation ][ location ].count;
    
    //generate counter
    $(counterElement).append("<span class = 'symbol substract'> - </span>");
    $(counterElement).append("<span class = 'value'>" +   employeeCount +  "</span>");
    $(counterElement).append("<span class = 'symbol add'> + </span>");    
    
    //initiate symbol and value elements
    //children always returns array so indexing is done to make sure only dom element is obtained
    addSymbolElement = $(counterElement).children('.add')[0];
    valueElement = $(counterElement).children('.value')[0];
    substractSymbolElement = $(counterElement).children('.substract')[0];
    
    //when add employee is clicked
    $(addSymbolElement).click( function( event ){
//       console.log(event);
      console.log( employeeCount + 1 );
      $(valueElement).html( ++ employeeCount );
      updateEmployeeCount(designation, location, 1);
    });
    
    //when substracct employee is clicked
    $(substractSymbolElement).click( function( event ){
//       console.log(event);
      if(  employeeCount === 0 ) return;
      console.log( employeeCount - 1 );
      $(valueElement).html( -- employeeCount  );
      updateEmployeeCount(designation, location, -1 );
    })
    
  })
}

//helper function which is not debounced yet
function updateEmployeeCount (designation, location, countVariation){
  
  //getting revenue and cost of that designation
  let rowIndex = empDesignationProfit.getDesignationIndex( designation );
  console.log('rowIndex', rowIndex);
  let revenue = empDesignationProfit.revenueCostDataTable.getValue(rowIndex, 1);
  let cost = empDesignationProfit.revenueCostDataTable.getValue(rowIndex, 2);
  //defining average cost and revenue rates
  let averageCost = empDesignationProfit.data[ designation ][ location ].averageCost;
  let averageRevenue = empDesignationProfit.data[ designation ][ location ].averageRevenue;
  console.log(averageRevenue, averageCost, countVariation);
  //variables holding cost and revenue to be added/substracted
  let revenueVariation = countVariation * averageRevenue;
  let costVariation = countVariation * averageCost;
  
  //recalculating cost and revenue based on variation and standard cost
  revenue += revenueVariation
  cost += costVariation
  //updating totalRevenue and totalCost
  empDesignationProfit.totalRevenue += revenueVariation;
  empDesignationProfit.totalCost += costVariation;
  
  //calculating updated profit
  //designation profit 
  let profit = empDesignationProfit.calculateProfit( revenue, cost );
  //overall profit
  empDesignationProfit.currentTotalProfit = empDesignationProfit.calculateProfit( empDesignationProfit.totalRevenue, empDesignationProfit.totalCost);
//   console.log('*****************************************************');
//   console.log('Designation : ' + designation);
//   console.log('Revenue : ' + revenue);
//   console.log('Cost : ' + cost);
//   console.log('Profit Margin : ' + profit);
//   console.log('averageRevenue : ' + averageRevenue);
//   console.log('averageCost : ' + averageCost);
//   console.log('totalRevenue : ' + empDesignationProfit.totalRevenue);
//   console.log('totalCost : ' + empDesignationProfit.totalCost);
  console.log('current Average Profit : ' + empDesignationProfit.currentTotalProfit);
//   console.log('*****************************************************');
  //updating chat data tables
  empDesignationProfit.revenueCostDataTable.setValue(rowIndex, 1, revenue);
  empDesignationProfit.revenueCostDataTable.setValue(rowIndex, 2, cost);
  empDesignationProfit.profitMarginCopyDataTable.setValue(rowIndex, 1, profit);
  
  //average profit margin for all designations
//   empDesignationProfit.calculateOverallProfit();
  
  //drawing charts 
  empDesignationProfit.drawCharts();
  
  //setting updated stats
  $('.profit_stats_container .change').html( empDesignationProfit.getProfitChange() );
  $('.profit_stats_container .current_profit').html( empDesignationProfit.currentTotalProfit.toFixed(2) )
}


// !!-- if performance is to be improved the updateEmployeeCount can be debounced //


